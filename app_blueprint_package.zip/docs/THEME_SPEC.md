# Theme Specification

Theme switching is supported (Light/Dark/System). Uses Material 3 design principles with custom overrides for Claude aesthetic.
