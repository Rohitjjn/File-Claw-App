# File Operations

All file operations use dart:io. Supports reading text, binary (images/archives). Editing is restricted to text-based files < 10MB.
