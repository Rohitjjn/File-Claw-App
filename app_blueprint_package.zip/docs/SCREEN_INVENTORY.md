# Screen Inventory

## Screens & Pages
- SplashScreen (/)
- HomeScreen (/home)
- SettingsScreen (/settings)
- AboutScreen (/about)
- SearchScreen (/search)
- FilePreviewScreen (/preview)
- EditorScreen (/editor)

## Dialogs, Drawers & Sheets
- SidebarDrawer
- ClaudeDialog
