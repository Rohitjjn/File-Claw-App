# Component Library

- **ClaudeAppBar**: Custom themed app bar.
- **ClaudeButton**: Primary action buttons.
- **ClaudeCard**: Surface containers.
- **FileIcon**: Icon rendering based on mime/extension.
- **EmptyState**: Standardized empty list state.
