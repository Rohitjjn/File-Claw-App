# Typography

## Font Families
- **Inter**: Used for all UI text (headings, body, labels).
- **Roboto Mono**: Used exclusively for code and file editors.
