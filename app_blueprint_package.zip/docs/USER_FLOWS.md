# User Flows

1. Launch -> Splash -> Home.
2. Home -> Open File -> Preview -> Edit (optional) -> Save.
