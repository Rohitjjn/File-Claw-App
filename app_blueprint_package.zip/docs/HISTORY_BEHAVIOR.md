# History Behavior

Recent files are saved to `file_history.json`. Allows clearing history.
