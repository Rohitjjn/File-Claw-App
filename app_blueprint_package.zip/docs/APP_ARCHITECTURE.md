# App Architecture

Feature-based folder structure: `lib/features/`, `lib/core/`, `lib/models/`, `lib/services/`. Uses Riverpod for state management.
