# Design System

The app uses a custom theme system inspired by Claude's aesthetic, with terracotta orange primary colors, Inter for UI text, and Roboto Mono for code.
