# Product Requirements Document

## Purpose
Files Claw is a local-only file previewer and editor with a Claude-inspired aesthetic.
## Core Features
- File browsing and previewing (text, code, images, archives, CSV).
- Code editing with syntax highlighting.
- History tracking.
- Local search.
- Fully offline.
