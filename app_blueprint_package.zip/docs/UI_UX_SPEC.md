# UI/UX Specification

## Navigation
- Main navigation through Home.
- Quick actions available on Android launcher.
- Route transitions use fade (for top-level) and slide (for deeper navigation).
