# App Overview

Files Claw is a Flutter application designed for previewing and editing files locally, utilizing a clean, distraction-free aesthetic.
