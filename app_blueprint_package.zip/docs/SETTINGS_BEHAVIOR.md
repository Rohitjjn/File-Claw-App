# Settings Behavior

Configured via SharedPreferences or local JSON config repository. Controls theme, history limit, etc.
