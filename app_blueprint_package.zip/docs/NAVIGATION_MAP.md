# Navigation Map

`/` (Splash) -> `/home`
`/home` -> `/search`, `/settings`, `/preview`, `/about`
`/preview` -> `/editor` (if editable)
