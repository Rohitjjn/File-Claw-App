# Search Behavior

Local search filtering on file history.
