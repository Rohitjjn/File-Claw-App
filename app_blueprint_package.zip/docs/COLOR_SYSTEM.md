# Color System

## Primary
- Terracotta Orange (`#D97757`)
## Light Theme
- Background: `#FAF9F8`
- Surface: `#FFFFFF`
- Text Primary: `#201F1E`
- Text Secondary: `#605E5C`
- Border: `#EDEBE9`
## Dark Theme
- Background: `#1C1C1E`
- Surface: `#2C2C2E`
- Text Primary: `#FFFFFF`
- Text Secondary: `#EBEBF5` (60%)
- Border: `#38383A`
