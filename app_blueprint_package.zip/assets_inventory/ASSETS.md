# Assets Inventory

## Icons
- `assets/icons/logo.png`
