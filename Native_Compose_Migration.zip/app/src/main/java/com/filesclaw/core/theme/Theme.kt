package com.filesclaw.core.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PrimaryColor = Color(0xFFD97757)
val PrimaryVariant = Color(0xFFB95C3D)

private val LightColors = lightColorScheme(
    primary = PrimaryColor,
    onPrimary = Color.White,
    background = Color(0xFFFAFAF8),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF2D2D2D)
)

private val DarkColors = darkColorScheme(
    primary = PrimaryColor,
    onPrimary = Color.White,
    background = Color(0xFF1A1A1A),
    surface = Color(0xFF2D2D2D),
    onSurface = Color(0xFFE5E5E5)
)

@Composable
fun FilesClawTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
